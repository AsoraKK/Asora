import { HttpRequest, HttpResponseInit, InvocationContext } from '@azure/functions';
declare const httpTrigger: (req: HttpRequest, context: InvocationContext) => Promise<HttpResponseInit>;
export default httpTrigger;
//# sourceMappingURL=token.d.ts.map