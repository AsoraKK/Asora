import { app } from '@azure/functions';
import { healthCheck } from './healthCheck';
app.http('health', {
    methods: ['GET'],
    authLevel: 'anonymous',
    route: 'health',
    handler: healthCheck
});
//# sourceMappingURL=index.js.map