export {};
//# sourceMappingURL=validate-privacy.d.ts.map