import type { Config } from 'jest';
declare const config: Config;
export default config;
//# sourceMappingURL=jest.config.d.ts.map